<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zzHa7KeosksT34Ru',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/verify-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verify-code',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/resend-verify-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'resend-verify-code',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/banks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qQ9ckobcTQYcx7MW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user-exists' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JG6HhBLMqbN9WEyV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/resolve-account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZOvTd49H7ZAZDtDn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xc1wK0PkBKJKuup6',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0QhM6354nYW6sVN8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/update-bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fjQWq7R10nUzdo2t',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2aH9IrQGrWloqrw6',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/next-of-kin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P3HhSOA8b9CUWtZS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2LwJiqn7pjHbEUz8',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/withdrawals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::21J9GFctqvMh0INK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/withdrawal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4y9EFfckVqjI8hXW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/investments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5SkdujinQ0PhiggE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/investment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U1nEjJfuiRDffW54',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LBW5kYEEbvj4EWjB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/confirm-minimum-unit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e3zTa4dmVSPKrQIv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a5sHSTT6pcqWCE6n',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r30ZzvCZvYFbXDSU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/documents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IblWJ1fYto0dFRZx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/document' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dwiIkIYN5Rp5ZOkW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/create-roi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g3CzBXNaDJwSb8d2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1qN68TUWCSCrUUNI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9wt7ggPj6dj7wNF0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|invest(?|or/investment/([^/]++)(?|(*:49))|ment/([^/]++)(*:70))|admin/(?|order/([^/]++)(?|(*:104))|document/([^/]++)(?|(*:133)))|verify\\-payment/([^/]++)(*:167)))/?$}sDu',
    ),
    3 => 
    array (
      49 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EBxZELaSkhP1pOEU',
          ),
          1 => 
          array (
            0 => 'investment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ot4C5uTCfGLSQq3x',
          ),
          1 => 
          array (
            0 => 'investment',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      70 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zkFdYPcz9RlS3KmK',
          ),
          1 => 
          array (
            0 => 'investment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rgzNAMwVHDj1G8t5',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JBsEzYIBxZgTTShA',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8zVjAAlWZ6PZsajQ',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BVhxgdniAil0ac5P',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2hC5Jod3fq85Aivy',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PzhpWUXNWxei1AMk',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      167 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WTdNltpt2ZSfMUUu',
          ),
          1 => 
          array (
            0 => 'reference',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::zzHa7KeosksT34Ru' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::zzHa7KeosksT34Ru',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\API\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\API\\AuthController@register',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\PasswordController@sendForgotPasswordLink',
        'controller' => 'App\\Http\\Controllers\\API\\PasswordController@sendForgotPasswordLink',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\PasswordController@resetPassword',
        'controller' => 'App\\Http\\Controllers\\API\\PasswordController@resetPassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verify-code' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/verify-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\VerificationController@verifyCode',
        'controller' => 'App\\Http\\Controllers\\API\\VerificationController@verifyCode',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'verify-code',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'resend-verify-code' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/resend-verify-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\VerificationController@resendVerifyCode',
        'controller' => 'App\\Http\\Controllers\\API\\VerificationController@resendVerifyCode',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'resend-verify-code',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qQ9ckobcTQYcx7MW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/banks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\BankController@index',
        'controller' => 'App\\Http\\Controllers\\API\\BankController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qQ9ckobcTQYcx7MW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JG6HhBLMqbN9WEyV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user-exists',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserController@checkIfUserExist',
        'controller' => 'App\\Http\\Controllers\\API\\UserController@checkIfUserExist',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::JG6HhBLMqbN9WEyV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZOvTd49H7ZAZDtDn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/resolve-account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserBankController@resolveAccount',
        'controller' => 'App\\Http\\Controllers\\API\\UserBankController@resolveAccount',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZOvTd49H7ZAZDtDn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Xc1wK0PkBKJKuup6' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/investor/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestorController@update',
        'controller' => 'App\\Http\\Controllers\\API\\InvestorController@update',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::Xc1wK0PkBKJKuup6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0QhM6354nYW6sVN8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestorController@profile',
        'controller' => 'App\\Http\\Controllers\\API\\InvestorController@profile',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::0QhM6354nYW6sVN8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fjQWq7R10nUzdo2t' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/update-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserBankController@store',
        'controller' => 'App\\Http\\Controllers\\API\\UserBankController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::fjQWq7R10nUzdo2t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2aH9IrQGrWloqrw6' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/investor/bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserBankController@delete',
        'controller' => 'App\\Http\\Controllers\\API\\UserBankController@delete',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::2aH9IrQGrWloqrw6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P3HhSOA8b9CUWtZS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/next-of-kin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\NextOfKinController@store',
        'controller' => 'App\\Http\\Controllers\\API\\NextOfKinController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::P3HhSOA8b9CUWtZS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2LwJiqn7pjHbEUz8' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/investor/next-of-kin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\NextOfKinController@delete',
        'controller' => 'App\\Http\\Controllers\\API\\NextOfKinController@delete',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::2LwJiqn7pjHbEUz8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::21J9GFctqvMh0INK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/withdrawals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\WithdrawalController@index',
        'controller' => 'App\\Http\\Controllers\\API\\WithdrawalController@index',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::21J9GFctqvMh0INK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4y9EFfckVqjI8hXW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/withdrawal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\WithdrawalController@store',
        'controller' => 'App\\Http\\Controllers\\API\\WithdrawalController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::4y9EFfckVqjI8hXW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5SkdujinQ0PhiggE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/investments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@index',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@index',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::5SkdujinQ0PhiggE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U1nEjJfuiRDffW54' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/investment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@store',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::U1nEjJfuiRDffW54',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EBxZELaSkhP1pOEU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/investment/{investment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@show',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@show',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::EBxZELaSkhP1pOEU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ot4C5uTCfGLSQq3x' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/investor/investment/{investment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::ot4C5uTCfGLSQq3x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LBW5kYEEbvj4EWjB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestmentController@index',
        'controller' => 'App\\Http\\Controllers\\API\\InvestmentController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::LBW5kYEEbvj4EWjB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zkFdYPcz9RlS3KmK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investment/{investment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestmentController@show',
        'controller' => 'App\\Http\\Controllers\\API\\InvestmentController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::zkFdYPcz9RlS3KmK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e3zTa4dmVSPKrQIv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/confirm-minimum-unit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestmentController@checkMinimumUnit',
        'controller' => 'App\\Http\\Controllers\\API\\InvestmentController@checkMinimumUnit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::e3zTa4dmVSPKrQIv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a5sHSTT6pcqWCE6n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\OrderController@index',
        'controller' => 'App\\Http\\Controllers\\API\\OrderController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::a5sHSTT6pcqWCE6n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r30ZzvCZvYFbXDSU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\OrderController@store',
        'controller' => 'App\\Http\\Controllers\\API\\OrderController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::r30ZzvCZvYFbXDSU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rgzNAMwVHDj1G8t5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/order/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\OrderController@update',
        'controller' => 'App\\Http\\Controllers\\API\\OrderController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::rgzNAMwVHDj1G8t5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JBsEzYIBxZgTTShA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/order/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\OrderController@show',
        'controller' => 'App\\Http\\Controllers\\API\\OrderController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::JBsEzYIBxZgTTShA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8zVjAAlWZ6PZsajQ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/order/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\OrderController@destroy',
        'controller' => 'App\\Http\\Controllers\\API\\OrderController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::8zVjAAlWZ6PZsajQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IblWJ1fYto0dFRZx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/documents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\DocumentController@index',
        'controller' => 'App\\Http\\Controllers\\API\\DocumentController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::IblWJ1fYto0dFRZx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dwiIkIYN5Rp5ZOkW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/document',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\DocumentController@store',
        'controller' => 'App\\Http\\Controllers\\API\\DocumentController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::dwiIkIYN5Rp5ZOkW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BVhxgdniAil0ac5P' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/document/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\DocumentController@update',
        'controller' => 'App\\Http\\Controllers\\API\\DocumentController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::BVhxgdniAil0ac5P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2hC5Jod3fq85Aivy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/document/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\DocumentController@show',
        'controller' => 'App\\Http\\Controllers\\API\\DocumentController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::2hC5Jod3fq85Aivy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PzhpWUXNWxei1AMk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/document/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\DocumentController@destroy',
        'controller' => 'App\\Http\\Controllers\\API\\DocumentController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::PzhpWUXNWxei1AMk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g3CzBXNaDJwSb8d2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/create-roi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\ROIController@store',
        'controller' => 'App\\Http\\Controllers\\API\\ROIController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::g3CzBXNaDJwSb8d2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1qN68TUWCSCrUUNI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\PasswordController@changePassword',
        'controller' => 'App\\Http\\Controllers\\API\\PasswordController@changePassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::1qN68TUWCSCrUUNI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WTdNltpt2ZSfMUUu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/verify-payment/{reference}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@verifyPayment',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@verifyPayment',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::WTdNltpt2ZSfMUUu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9wt7ggPj6dj7wNF0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:262:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000018d94931000000002103a22e";}";s:4:"hash";s:44:"FD3y5HEBIVIACz9ZAyjQTBzUU7cH793+YIfHgKmsN/Y=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9wt7ggPj6dj7wNF0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
