<?php

namespace App\Http\Middleware;
use Illuminate\Support\Facades\Auth;
use Closure;
use Illuminate\Http\Request;

class Employee
{

    public function handle($request, Closure $next)
    {
         if (Auth::user() &&  Auth::user()->role_id == 18) {
                return $next($request);
         }

        return response()->json('Unauthorized!, You are not an employee', 403);
    }
}
