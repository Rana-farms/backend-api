<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VdTuP8eh0PRvlMxP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/verify-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verify-code',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/resend-verify-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'resend-verify-code',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/banks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Kf8fH58xIuao3HhS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user-exists' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m8wOPIr92tQz9KVH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l05D6LLl3VuVV9Xh',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oPugyaCKg19frbBG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/update-bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MJqkxt058nfqz1Gy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/bank' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8Uw9AH8ggEcxGOgT',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/resolve-account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C5CpAe9RZI8isht3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/next-of-kin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0hotgLUNkqxztJ7E',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IX4HKuaujElbIWBv',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/withdrawals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qhprXvTEKIBF85Jd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/withdrawal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X7zKmW8H3crS8Brl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/investments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hMbXjeLUruM5mUSJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/investment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rmw91XzXs3JFkgwL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investor/process-payment' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5k8mANc3gkeUhpKf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/investments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gllbquw12Bt3vDKu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/confirm-minimum-unit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HSZa89YZ2oodobwd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/change-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m5i2Dn8v3hK0wcyF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RuS4p5VOIjZwnbsg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/invest(?|or/investment/([^/]++)(?|(*:46))|ment/([^/]++)(*:67)))/?$}sDu',
    ),
    3 => 
    array (
      46 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fPAitDWuT6ehpbZg',
          ),
          1 => 
          array (
            0 => 'investment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hFBeTWdarW9VV5Jl',
          ),
          1 => 
          array (
            0 => 'investment',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      67 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aaeR2SOL9hFtYWol',
          ),
          1 => 
          array (
            0 => 'investment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::VdTuP8eh0PRvlMxP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::VdTuP8eh0PRvlMxP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\API\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\API\\AuthController@register',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\PasswordController@sendForgotPasswordLink',
        'controller' => 'App\\Http\\Controllers\\API\\PasswordController@sendForgotPasswordLink',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\PasswordController@resetPassword',
        'controller' => 'App\\Http\\Controllers\\API\\PasswordController@resetPassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verify-code' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/verify-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\VerificationController@verifyCode',
        'controller' => 'App\\Http\\Controllers\\API\\VerificationController@verifyCode',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'verify-code',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'resend-verify-code' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/resend-verify-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\VerificationController@resendVerifyCode',
        'controller' => 'App\\Http\\Controllers\\API\\VerificationController@resendVerifyCode',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'resend-verify-code',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Kf8fH58xIuao3HhS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/banks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\BankController@index',
        'controller' => 'App\\Http\\Controllers\\API\\BankController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Kf8fH58xIuao3HhS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m8wOPIr92tQz9KVH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user-exists',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserController@checkIfUserExist',
        'controller' => 'App\\Http\\Controllers\\API\\UserController@checkIfUserExist',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::m8wOPIr92tQz9KVH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l05D6LLl3VuVV9Xh' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/investor/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestorController@update',
        'controller' => 'App\\Http\\Controllers\\API\\InvestorController@update',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::l05D6LLl3VuVV9Xh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oPugyaCKg19frbBG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestorController@profile',
        'controller' => 'App\\Http\\Controllers\\API\\InvestorController@profile',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::oPugyaCKg19frbBG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MJqkxt058nfqz1Gy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/update-bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserBankController@store',
        'controller' => 'App\\Http\\Controllers\\API\\UserBankController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::MJqkxt058nfqz1Gy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8Uw9AH8ggEcxGOgT' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/investor/bank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserBankController@delete',
        'controller' => 'App\\Http\\Controllers\\API\\UserBankController@delete',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::8Uw9AH8ggEcxGOgT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C5CpAe9RZI8isht3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/resolve-account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserBankController@resolveAccount',
        'controller' => 'App\\Http\\Controllers\\API\\UserBankController@resolveAccount',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::C5CpAe9RZI8isht3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0hotgLUNkqxztJ7E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/next-of-kin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\NextOfKinController@store',
        'controller' => 'App\\Http\\Controllers\\API\\NextOfKinController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::0hotgLUNkqxztJ7E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IX4HKuaujElbIWBv' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/investor/next-of-kin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\NextOfKinController@delete',
        'controller' => 'App\\Http\\Controllers\\API\\NextOfKinController@delete',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::IX4HKuaujElbIWBv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qhprXvTEKIBF85Jd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/withdrawals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\WithdrawalController@index',
        'controller' => 'App\\Http\\Controllers\\API\\WithdrawalController@index',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::qhprXvTEKIBF85Jd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X7zKmW8H3crS8Brl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/withdrawal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\WithdrawalController@store',
        'controller' => 'App\\Http\\Controllers\\API\\WithdrawalController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::X7zKmW8H3crS8Brl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hMbXjeLUruM5mUSJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/investments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@index',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@index',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::hMbXjeLUruM5mUSJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rmw91XzXs3JFkgwL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/investment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@store',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@store',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::rmw91XzXs3JFkgwL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fPAitDWuT6ehpbZg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investor/investment/{investment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@show',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@show',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::fPAitDWuT6ehpbZg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hFBeTWdarW9VV5Jl' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/investor/investment/{investment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\UserInvestmentController@destroy',
        'controller' => 'App\\Http\\Controllers\\API\\UserInvestmentController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::hFBeTWdarW9VV5Jl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5k8mANc3gkeUhpKf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/investor/process-payment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
          4 => 'investor',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\PaymentController@processInvestmentPayment',
        'controller' => 'App\\Http\\Controllers\\API\\PaymentController@processInvestmentPayment',
        'namespace' => NULL,
        'prefix' => 'api/investor',
        'where' => 
        array (
        ),
        'as' => 'generated::5k8mANc3gkeUhpKf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gllbquw12Bt3vDKu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestmentController@index',
        'controller' => 'App\\Http\\Controllers\\API\\InvestmentController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::gllbquw12Bt3vDKu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aaeR2SOL9hFtYWol' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/investment/{investment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestmentController@show',
        'controller' => 'App\\Http\\Controllers\\API\\InvestmentController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::aaeR2SOL9hFtYWol',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HSZa89YZ2oodobwd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/confirm-minimum-unit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\InvestmentController@checkMinimumUnit',
        'controller' => 'App\\Http\\Controllers\\API\\InvestmentController@checkMinimumUnit',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::HSZa89YZ2oodobwd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m5i2Dn8v3hK0wcyF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/change-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'json',
          2 => 'auth:sanctum',
          3 => 'verified',
        ),
        'uses' => 'App\\Http\\Controllers\\API\\PasswordController@changePassword',
        'controller' => 'App\\Http\\Controllers\\API\\PasswordController@changePassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::m5i2Dn8v3hK0wcyF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RuS4p5VOIjZwnbsg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:262:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000004e12e5dc000000007e029dd5";}";s:4:"hash";s:44:"34kaYC9pLPE3ToO5+Yd57ZITIcDt2FXWF7rYv2Nmxko=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RuS4p5VOIjZwnbsg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
